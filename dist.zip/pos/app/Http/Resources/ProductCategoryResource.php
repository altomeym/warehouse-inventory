<?php

namespace App\Http\Resources;

/**
 * Class ProductCategoryResource
 */
class ProductCategoryResource extends BaseJsonResource
{

}
