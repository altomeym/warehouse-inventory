<?php

namespace App\Http\Resources;

/**
 * Class BrandCollection
 */
class BrandCollection extends BaseCollection
{
    public $collects = BrandResource::class;
}
