<?php

namespace App\Http\Resources;

/**
 * Class SaleResource
 */
class SaleResource extends BaseJsonResource
{

}
