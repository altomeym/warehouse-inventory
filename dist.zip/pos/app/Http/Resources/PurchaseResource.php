<?php

namespace App\Http\Resources;

/**
 * Class PurchaseResource
 */
class PurchaseResource extends BaseJsonResource
{

}
