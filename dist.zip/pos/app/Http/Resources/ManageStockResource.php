<?php

namespace App\Http\Resources;

/**
 * Class ManageStockResource
 */
class ManageStockResource extends BaseJsonResource
{

}
