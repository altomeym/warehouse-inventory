<?php

namespace App\Http\Resources;

/**
 * Class SmsTemplateCollection
 */
class SmsTemplateCollection extends BaseCollection
{
    public $collects = SmsTemplateResource::class;
}
