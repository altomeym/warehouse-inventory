<?php

namespace App\Http\Resources;

/**
 * Class BrandResource
 */
class BrandResource extends BaseJsonResource
{

}
