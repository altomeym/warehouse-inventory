<?php

namespace App\Http\Resources;

/**
 * Class CustomerCollection
 */
class CustomerCollection extends BaseCollection
{
    public $collects = CustomerResource::class;
}
