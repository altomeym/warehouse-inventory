<?php

namespace App\Http\Resources;

/**
 * Class PurchaseResource
 */
class PurchaseReturnResource extends BaseJsonResource
{

}
