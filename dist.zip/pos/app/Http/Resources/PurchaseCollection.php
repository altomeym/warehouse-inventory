<?php

namespace App\Http\Resources;

/**
 * Class ExpenseCategoryCollection
 */
class PurchaseCollection extends BaseCollection
{
    public $collects = PurchaseResource::class;
}
