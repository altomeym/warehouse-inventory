<?php

namespace App\Http\Resources;

/**
 * Class UserResource
 */
class UserResource extends BaseJsonResource
{

}
