<?php

namespace App\Http\Resources;

/**
 * Class UnitResource
 */
class UnitResource extends BaseJsonResource
{

}
