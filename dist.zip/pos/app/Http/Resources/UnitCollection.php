<?php

namespace App\Http\Resources;

/**
 * Class UnitCollection
 */
class UnitCollection extends BaseCollection
{
    public $collects = UnitResource::class;
}
