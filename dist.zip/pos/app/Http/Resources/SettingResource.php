<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

/**
 * Class SettingResource
 */
class SettingResource extends JsonResource
{

}
