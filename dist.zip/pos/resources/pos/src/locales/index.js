import ar from "./ar.json"; // Arabic
import en from "./en.json"; // English
import fr from "./fr.json"; // French
import gr from "./gr.json"; // German
import sp from "./sp.json"; // Spanish
import tr from "./tr.json"; // Turkish
import vi from "./vi.json"  // Vietnamese
import cn from "./cn.json"  // Chinese

export default { ar, en, fr, gr, sp, tr, vi, cn };
